#!/bin/bash
rm *.ini
rm *.test